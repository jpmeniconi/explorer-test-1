"use client"

import { useState } from "react"
import { ComposableMap, Geographies, Geography, Marker, ZoomableGroup } from "react-simple-maps"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import {
  Search,
  Layers,
  MapPin,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Settings,
  Download,
  Share2,
  ChevronLeft,
  ChevronRight,
  Globe,
} from "lucide-react"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { GlobeToMapTransform } from "@/components/globe-to-map-transform"

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json"

// Mock projects data
const mockProjects = [
  // North America (25 projects)
  {
    id: 1,
    name: "Earthship Biotecture",
    location: "New Mexico, USA",
    coordinates: [-106.0, 36.0],
    type: "Passive House",
    status: "Completed",
    year: 2023,
    image: "/earthship-sustainable-building-desert.jpg",
  },
  {
    id: 2,
    name: "Bullitt Center",
    location: "Seattle, USA",
    coordinates: [-122.32, 47.61],
    type: "Living Building",
    status: "Completed",
    year: 2022,
    image: "/bullitt-center-green-building-seattle.jpg",
  },
  {
    id: 3,
    name: "Phipps Center",
    location: "Pittsburgh, USA",
    coordinates: [-79.95, 40.44],
    type: "Net Zero",
    status: "Completed",
    year: 2021,
    image: "/phipps-conservatory-sustainable-building.jpg",
  },
  {
    id: 4,
    name: "Manitoba Hydro",
    location: "Winnipeg, CA",
    coordinates: [-97.14, 49.89],
    type: "LEED Platinum",
    status: "Completed",
    year: 2020,
    image: "/manitoba-hydro-tower-green-building.jpg",
  },
  {
    id: 5,
    name: "Vancouver Convention",
    location: "Vancouver, CA",
    coordinates: [-123.12, 49.28],
    type: "LEED Platinum",
    status: "Completed",
    year: 2019,
    image: "/vancouver-convention-center-green-roof.jpg",
  },
  {
    id: 6,
    name: "San Francisco Living",
    location: "San Francisco, USA",
    coordinates: [-122.42, 37.77],
    type: "Net Zero",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 7,
    name: "Portland Eco Tower",
    location: "Portland, USA",
    coordinates: [-122.68, 45.52],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 8,
    name: "Denver Solar Hub",
    location: "Denver, USA",
    coordinates: [-104.99, 39.74],
    type: "Solar",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 9,
    name: "Austin Green District",
    location: "Austin, USA",
    coordinates: [-97.74, 30.27],
    type: "Smart City",
    status: "Planned",
    year: 2025,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 10,
    name: "Chicago Retrofit",
    location: "Chicago, USA",
    coordinates: [-87.63, 41.88],
    type: "Retrofit",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 11,
    name: "Boston Passive",
    location: "Boston, USA",
    coordinates: [-71.06, 42.36],
    type: "Passive House",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 12,
    name: "New York Green",
    location: "New York, USA",
    coordinates: [-74.01, 40.71],
    type: "LEED Platinum",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 13,
    name: "Miami Solar",
    location: "Miami, USA",
    coordinates: [-80.19, 25.76],
    type: "Solar",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 14,
    name: "Toronto Eco",
    location: "Toronto, CA",
    coordinates: [-79.38, 43.65],
    type: "Green Building",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 15,
    name: "Montreal Passive",
    location: "Montreal, CA",
    coordinates: [-73.57, 45.5],
    type: "Passive House",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 16,
    name: "Los Angeles Net Zero",
    location: "Los Angeles, USA",
    coordinates: [-118.24, 34.05],
    type: "Net Zero",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 17,
    name: "Phoenix Solar",
    location: "Phoenix, USA",
    coordinates: [-112.07, 33.45],
    type: "Solar",
    status: "Planned",
    year: 2025,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 18,
    name: "Dallas Green",
    location: "Dallas, USA",
    coordinates: [-96.8, 32.78],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 19,
    name: "Houston Sustainable",
    location: "Houston, USA",
    coordinates: [-95.37, 29.76],
    type: "LEED Platinum",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 20,
    name: "Philadelphia Eco",
    location: "Philadelphia, USA",
    coordinates: [-75.16, 39.95],
    type: "Retrofit",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 21,
    name: "Atlanta Green Tower",
    location: "Atlanta, USA",
    coordinates: [-84.39, 33.75],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 22,
    name: "Minneapolis Passive",
    location: "Minneapolis, USA",
    coordinates: [-93.27, 44.98],
    type: "Passive House",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 23,
    name: "Calgary Solar",
    location: "Calgary, CA",
    coordinates: [-114.07, 51.05],
    type: "Solar",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 24,
    name: "Mexico City Green",
    location: "Mexico City, MX",
    coordinates: [-99.13, 19.43],
    type: "Green Building",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 25,
    name: "Guadalajara Eco",
    location: "Guadalajara, MX",
    coordinates: [-103.35, 20.67],
    type: "LEED Platinum",
    status: "Planned",
    year: 2025,
    image: "/placeholder.svg?height=400&width=600",
  },

  // South America (15 projects)
  {
    id: 26,
    name: "São Paulo Green",
    location: "São Paulo, BR",
    coordinates: [-46.63, -23.55],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 27,
    name: "Rio Sustainable",
    location: "Rio de Janeiro, BR",
    coordinates: [-43.17, -22.91],
    type: "LEED Platinum",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 28,
    name: "Buenos Aires Eco",
    location: "Buenos Aires, AR",
    coordinates: [-58.38, -34.6],
    type: "Retrofit",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 29,
    name: "Santiago Solar",
    location: "Santiago, CL",
    coordinates: [-70.65, -33.45],
    type: "Solar",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 30,
    name: "Lima Green Tower",
    location: "Lima, PE",
    coordinates: [-77.04, -12.05],
    type: "Green Building",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 31,
    name: "Bogotá Passive",
    location: "Bogotá, CO",
    coordinates: [-74.08, 4.71],
    type: "Passive House",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 32,
    name: "Quito Eco",
    location: "Quito, EC",
    coordinates: [-78.47, -0.18],
    type: "LEED Platinum",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 33,
    name: "Caracas Green",
    location: "Caracas, VE",
    coordinates: [-66.9, 10.49],
    type: "Green Building",
    status: "Planned",
    year: 2025,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 34,
    name: "Montevideo Solar",
    location: "Montevideo, UY",
    coordinates: [-56.16, -34.9],
    type: "Solar",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 35,
    name: "Brasília Sustainable",
    location: "Brasília, BR",
    coordinates: [-47.88, -15.79],
    type: "Smart City",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 36,
    name: "Medellín Green",
    location: "Medellín, CO",
    coordinates: [-75.56, 6.25],
    type: "Green Building",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 37,
    name: "Curitiba Eco",
    location: "Curitiba, BR",
    coordinates: [-49.27, -25.43],
    type: "LEED Platinum",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 38,
    name: "Córdoba Solar",
    location: "Córdoba, AR",
    coordinates: [-64.18, -31.42],
    type: "Solar",
    status: "Planned",
    year: 2025,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 39,
    name: "Valparaíso Green",
    location: "Valparaíso, CL",
    coordinates: [-71.62, -33.05],
    type: "Retrofit",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 40,
    name: "La Paz Passive",
    location: "La Paz, BO",
    coordinates: [-68.15, -16.5],
    type: "Passive House",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },

  // Europe (25 projects)
  {
    id: 41,
    name: "BedZED",
    location: "London, UK",
    coordinates: [-0.15, 51.4],
    type: "Zero Carbon",
    status: "Completed",
    year: 2002,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 42,
    name: "The Edge",
    location: "Amsterdam, NL",
    coordinates: [4.95, 52.34],
    type: "Net Positive",
    status: "Completed",
    year: 2014,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 43,
    name: "Bosco Verticale",
    location: "Milan, IT",
    coordinates: [9.19, 45.48],
    type: "Green Building",
    status: "Completed",
    year: 2014,
    image: "/vertical-forest-building-green-facade.jpg",
  },
  {
    id: 44,
    name: "Powerhouse Kjørbo",
    location: "Oslo, NO",
    coordinates: [10.52, 59.92],
    type: "Energy Positive",
    status: "Completed",
    year: 2014,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 45,
    name: "Freiburg Solar",
    location: "Freiburg, DE",
    coordinates: [7.85, 47.99],
    type: "Solar District",
    status: "Completed",
    year: 2006,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 46,
    name: "Vauban District",
    location: "Freiburg, DE",
    coordinates: [7.83, 48.01],
    type: "Car-Free",
    status: "Completed",
    year: 2006,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 47,
    name: "Passive House Berlin",
    location: "Berlin, DE",
    coordinates: [13.4, 52.52],
    type: "Passive House",
    status: "Completed",
    year: 2020,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 48,
    name: "Copenhagen Green",
    location: "Copenhagen, DK",
    coordinates: [12.57, 55.68],
    type: "Green Building",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 49,
    name: "Stockholm Eco",
    location: "Stockholm, SE",
    coordinates: [18.07, 59.33],
    type: "LEED Platinum",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 50,
    name: "Helsinki Passive",
    location: "Helsinki, FI",
    coordinates: [24.94, 60.17],
    type: "Passive House",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 51,
    name: "Paris Green Tower",
    location: "Paris, FR",
    coordinates: [2.35, 48.86],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 52,
    name: "Barcelona Solar",
    location: "Barcelona, ES",
    coordinates: [2.17, 41.39],
    type: "Solar",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 53,
    name: "Madrid Eco",
    location: "Madrid, ES",
    coordinates: [-3.7, 40.42],
    type: "LEED Platinum",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 54,
    name: "Rome Retrofit",
    location: "Rome, IT",
    coordinates: [12.5, 41.9],
    type: "Retrofit",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 55,
    name: "Vienna Passive",
    location: "Vienna, AT",
    coordinates: [16.37, 48.21],
    type: "Passive House",
    status: "Completed",
    year: 2020,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 56,
    name: "Zurich Green",
    location: "Zurich, CH",
    coordinates: [8.54, 47.38],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 57,
    name: "Brussels Eco",
    location: "Brussels, BE",
    coordinates: [4.35, 50.85],
    type: "LEED Platinum",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 58,
    name: "Dublin Solar",
    location: "Dublin, IE",
    coordinates: [-6.26, 53.35],
    type: "Solar",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 59,
    name: "Lisbon Green",
    location: "Lisbon, PT",
    coordinates: [-9.14, 38.72],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 60,
    name: "Prague Passive",
    location: "Prague, CZ",
    coordinates: [14.42, 50.08],
    type: "Passive House",
    status: "Planned",
    year: 2025,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 61,
    name: "Warsaw Eco",
    location: "Warsaw, PL",
    coordinates: [21.01, 52.23],
    type: "LEED Platinum",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 62,
    name: "Budapest Green",
    location: "Budapest, HU",
    coordinates: [19.04, 47.5],
    type: "Green Building",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 63,
    name: "Athens Solar",
    location: "Athens, GR",
    coordinates: [23.73, 37.98],
    type: "Solar",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 64,
    name: "Munich Passive",
    location: "Munich, DE",
    coordinates: [11.58, 48.14],
    type: "Passive House",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 65,
    name: "Hamburg Green",
    location: "Hamburg, DE",
    coordinates: [10.0, 53.55],
    type: "Green Building",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },

  // Africa (10 projects)
  {
    id: 66,
    name: "Cape Town Green",
    location: "Cape Town, ZA",
    coordinates: [18.42, -33.92],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 67,
    name: "Cairo Solar",
    location: "Cairo, EG",
    coordinates: [31.24, 30.04],
    type: "Solar",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 68,
    name: "Nairobi Eco",
    location: "Nairobi, KE",
    coordinates: [36.82, -1.29],
    type: "LEED Platinum",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 69,
    name: "Lagos Green Tower",
    location: "Lagos, NG",
    coordinates: [3.39, 6.52],
    type: "Green Building",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 70,
    name: "Johannesburg Passive",
    location: "Johannesburg, ZA",
    coordinates: [28.05, -26.2],
    type: "Passive House",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 71,
    name: "Casablanca Solar",
    location: "Casablanca, MA",
    coordinates: [-7.59, 33.57],
    type: "Solar",
    status: "Planned",
    year: 2025,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 72,
    name: "Accra Green",
    location: "Accra, GH",
    coordinates: [-0.19, 5.56],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 73,
    name: "Addis Ababa Eco",
    location: "Addis Ababa, ET",
    coordinates: [38.75, 9.03],
    type: "LEED Platinum",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 74,
    name: "Dar es Salaam Solar",
    location: "Dar es Salaam, TZ",
    coordinates: [39.27, -6.79],
    type: "Solar",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 75,
    name: "Tunis Green",
    location: "Tunis, TN",
    coordinates: [10.18, 36.81],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },

  // Asia (20 projects)
  {
    id: 76,
    name: "Masdar City",
    location: "Abu Dhabi, UAE",
    coordinates: [54.6, 24.4],
    type: "Smart City",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 77,
    name: "Bahrain WTC",
    location: "Manama, BH",
    coordinates: [50.6, 26.2],
    type: "Wind Power",
    status: "Completed",
    year: 2008,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 78,
    name: "Green School Bali",
    location: "Bali, ID",
    coordinates: [115.26, -8.52],
    type: "Bamboo",
    status: "Completed",
    year: 2008,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 79,
    name: "Taipei 101 Green",
    location: "Taipei, TW",
    coordinates: [121.56, 25.03],
    type: "Retrofit",
    status: "Completed",
    year: 2011,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 80,
    name: "Singapore Green",
    location: "Singapore, SG",
    coordinates: [103.85, 1.29],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 81,
    name: "Tokyo Passive",
    location: "Tokyo, JP",
    coordinates: [139.69, 35.69],
    type: "Passive House",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 82,
    name: "Seoul Eco Tower",
    location: "Seoul, KR",
    coordinates: [126.98, 37.57],
    type: "LEED Platinum",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 83,
    name: "Beijing Solar",
    location: "Beijing, CN",
    coordinates: [116.41, 39.9],
    type: "Solar",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 84,
    name: "Shanghai Green",
    location: "Shanghai, CN",
    coordinates: [121.47, 31.23],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 85,
    name: "Hong Kong Eco",
    location: "Hong Kong, HK",
    coordinates: [114.17, 22.32],
    type: "LEED Platinum",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 86,
    name: "Mumbai Green Tower",
    location: "Mumbai, IN",
    coordinates: [72.88, 19.08],
    type: "Green Building",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 87,
    name: "Delhi Solar",
    location: "Delhi, IN",
    coordinates: [77.21, 28.61],
    type: "Solar",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 88,
    name: "Bangkok Eco",
    location: "Bangkok, TH",
    coordinates: [100.5, 13.75],
    type: "LEED Platinum",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 89,
    name: "Kuala Lumpur Green",
    location: "Kuala Lumpur, MY",
    coordinates: [101.69, 3.14],
    type: "Green Building",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 90,
    name: "Jakarta Passive",
    location: "Jakarta, ID",
    coordinates: [106.85, -6.21],
    type: "Passive House",
    status: "Planned",
    year: 2025,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 91,
    name: "Manila Solar",
    location: "Manila, PH",
    coordinates: [120.98, 14.6],
    type: "Solar",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 92,
    name: "Hanoi Green",
    location: "Hanoi, VN",
    coordinates: [105.84, 21.03],
    type: "Green Building",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 93,
    name: "Bangalore Eco",
    location: "Bangalore, IN",
    coordinates: [77.59, 12.97],
    type: "LEED Platinum",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 94,
    name: "Shenzhen Green",
    location: "Shenzhen, CN",
    coordinates: [114.06, 22.54],
    type: "Green Building",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 95,
    name: "Osaka Passive",
    location: "Osaka, JP",
    coordinates: [135.5, 34.69],
    type: "Passive House",
    status: "Completed",
    year: 2021,
    image: "/placeholder.svg?height=400&width=600",
  },

  // Oceania (5 projects)
  {
    id: 96,
    name: "One Central Park",
    location: "Sydney, AU",
    coordinates: [151.2, -33.9],
    type: "Vertical Garden",
    status: "Completed",
    year: 2013,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 97,
    name: "Pixel Building",
    location: "Melbourne, AU",
    coordinates: [144.96, -37.81],
    type: "Carbon Neutral",
    status: "Completed",
    year: 2010,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 98,
    name: "Brisbane Green",
    location: "Brisbane, AU",
    coordinates: [153.03, -27.47],
    type: "Green Building",
    status: "Completed",
    year: 2022,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 99,
    name: "Auckland Eco",
    location: "Auckland, NZ",
    coordinates: [174.76, -36.85],
    type: "LEED Platinum",
    status: "In Progress",
    year: 2024,
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 100,
    name: "Perth Solar",
    location: "Perth, AU",
    coordinates: [115.86, -31.95],
    type: "Solar",
    status: "Completed",
    year: 2023,
    image: "/placeholder.svg?height=400&width=600",
  },
]

export default function MapPage() {
  const [leftPanelOpen, setLeftPanelOpen] = useState(true)
  const [rightPanelOpen, setRightPanelOpen] = useState(true)
  const [zoom, setZoom] = useState(1)
  const [position, setPosition] = useState({ coordinates: [0, 0], zoom: 1 })
  const [selectedProject, setSelectedProject] = useState<any>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [showHeatmap, setShowHeatmap] = useState(false)
  const [show3D, setShow3D] = useState(false)

  const handleZoomIn = () => setZoom(Math.min(zoom + 1, 3))
  const handleZoomOut = () => setZoom(Math.max(zoom - 1, 1))

  const handleUnroll = () => {
    setShow3D(false)
  }

  return (
    <div className="fixed inset-0 bg-black flex overflow-hidden">
      {/* Left Panel - Layers & Filters */}
      <div
        className={cn(
          "bg-background border-r border-border transition-all duration-300 flex flex-col",
          leftPanelOpen ? "w-80" : "w-0",
        )}
      >
        {leftPanelOpen && (
          <>
            {/* Panel Header */}
            <div className="p-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="h-5 w-5 text-primary" />
                <h2 className="font-semibold">Layers & Filters</h2>
              </div>
              <Button size="icon" variant="ghost" onClick={() => setLeftPanelOpen(false)}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
            </div>

            <ScrollArea className="flex-1">
              <div className="p-4 space-y-6">
                {/* Search */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Search Projects</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by name or location..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>

                {/* Map Layers */}
                <div className="space-y-3">
                  <label className="text-sm font-medium">Map Layers</label>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 rounded-lg hover:bg-accent">
                      <span className="text-sm">Project Markers</span>
                      <Switch defaultChecked disabled={show3D} />
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg hover:bg-accent">
                      <span className="text-sm">Country Borders</span>
                      <Switch defaultChecked disabled={show3D} />
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg hover:bg-accent">
                      <span className="text-sm">Heatmap View</span>
                      <Switch checked={showHeatmap} onCheckedChange={setShowHeatmap} disabled={show3D} />
                    </div>
                    <div className="flex items-center justify-between p-2 rounded-lg hover:bg-accent bg-accent/50">
                      <div className="flex items-center gap-2">
                        <Globe className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium">3D Globe View</span>
                      </div>
                      <Switch checked={show3D} onCheckedChange={setShow3D} />
                    </div>
                  </div>
                </div>

                {/* Project Type Filters */}
                <div className="space-y-3">
                  <label className="text-sm font-medium">Project Types</label>
                  <div className="space-y-2">
                    {[
                      "Passive House",
                      "Living Building",
                      "LEED Platinum",
                      "Net Zero",
                      "Solar",
                      "Green Building",
                      "Smart City",
                      "Retrofit",
                      "Zero Carbon",
                      "Net Positive",
                      "Energy Positive",
                      "Car-Free",
                      "Vertical Garden",
                      "Carbon Neutral",
                      "Wind Power",
                      "Bamboo",
                    ].map((type) => (
                      <div key={type} className="flex items-center gap-2">
                        <input type="checkbox" id={type} className="rounded" defaultChecked />
                        <label htmlFor={type} className="text-sm cursor-pointer">
                          {type}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Year Range */}
                <div className="space-y-3">
                  <label className="text-sm font-medium">Year Built</label>
                  <Slider defaultValue={[2010, 2024]} min={2000} max={2024} step={1} className="w-full" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>2010</span>
                    <span>2024</span>
                  </div>
                </div>

                {/* Status Filter */}
                <div className="space-y-3">
                  <label className="text-sm font-medium">Project Status</label>
                  <div className="space-y-2">
                    {["Completed", "In Progress", "Planned"].map((status) => (
                      <div key={status} className="flex items-center gap-2">
                        <input type="checkbox" id={status} className="rounded" defaultChecked />
                        <label htmlFor={status} className="text-sm cursor-pointer">
                          {status}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </ScrollArea>
          </>
        )}
      </div>

      {/* Main Map Area */}
      <div className="flex-1 relative">
        {/* Top Toolbar */}
        <div className="absolute top-16 left-0 right-0 z-20 bg-background/95 backdrop-blur-sm border-b border-border">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-4">
              {!leftPanelOpen && (
                <Button size="icon" variant="ghost" onClick={() => setLeftPanelOpen(true)}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              )}
              <div className="flex items-center gap-2">
                {show3D ? <Globe className="h-5 w-5 text-primary" /> : <MapPin className="h-5 w-5 text-primary" />}
                <h1 className="text-lg font-semibold">{show3D ? "3D Globe View" : "Global Projects Map"}</h1>
              </div>
              <Badge variant="secondary">
                Zoom: {zoom}/3 • {mockProjects.length} Projects
              </Badge>
            </div>

            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" className="gap-2 bg-transparent">
                <Download className="h-4 w-4" />
                Export
              </Button>
              <Button size="sm" variant="outline" className="gap-2 bg-transparent">
                <Share2 className="h-4 w-4" />
                Share
              </Button>
              <Button size="sm" variant="outline" className="gap-2 bg-transparent">
                <Settings className="h-4 w-4" />
                Settings
              </Button>
            </div>
          </div>
        </div>

        {/* Map Controls */}
        {!show3D && (
          <div className="absolute top-36 right-4 z-20 flex flex-col gap-2">
            <Button size="icon" variant="secondary" onClick={handleZoomIn} disabled={zoom === 3}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button size="icon" variant="secondary" onClick={handleZoomOut} disabled={zoom === 1}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button size="icon" variant="secondary">
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        )}

        {/* Map Container */}
        <div className="w-full h-full bg-black pt-[120px]">
          {show3D ? (
            <GlobeToMapTransform
              projects={mockProjects}
              onProjectClick={(project) => setSelectedProject(project)}
              onUnroll={handleUnroll}
            />
          ) : (
            <ComposableMap
              projection="geoMercator"
              projectionConfig={{
                scale: 147,
                center: [0, 20],
              }}
              width={800}
              height={600}
              style={{ width: "100%", height: "100%" }}
            >
              <ZoomableGroup zoom={position.zoom} center={position.coordinates as [number, number]}>
                <Geographies geography={geoUrl}>
                  {({ geographies }) =>
                    geographies.map((geo) => (
                      <Geography
                        key={geo.rsmKey}
                        geography={geo}
                        style={{
                          default: {
                            fill: "#0d9488",
                            stroke: "#14b8a6",
                            strokeWidth: 0.5,
                            outline: "none",
                          },
                          hover: {
                            fill: "#14b8a6",
                            stroke: "#f3f4f6",
                            strokeWidth: 1,
                            outline: "none",
                            cursor: "pointer",
                          },
                        }}
                      />
                    ))
                  }
                </Geographies>

                {mockProjects.map((project) => (
                  <Marker key={project.id} coordinates={project.coordinates}>
                    <g onClick={() => setSelectedProject(project)} style={{ cursor: "pointer" }}>
                      <circle
                        r={3}
                        fill="#ffffff"
                        stroke="#ffffff"
                        strokeWidth={0.5}
                        style={{ filter: "drop-shadow(0 0 4px #ffffff)" }}
                      >
                        <animate attributeName="r" values="3;5;3" dur="2s" repeatCount="indefinite" />
                        <animate attributeName="opacity" values="1;0.5;1" dur="2s" repeatCount="indefinite" />
                      </circle>
                    </g>
                  </Marker>
                ))}
              </ZoomableGroup>
            </ComposableMap>
          )}
        </div>
      </div>

      {/* Right Panel - Project Details */}
      <div
        className={cn(
          "bg-background border-l border-border transition-all duration-300 flex flex-col",
          rightPanelOpen ? "w-96" : "w-0",
        )}
      >
        {rightPanelOpen && (
          <>
            {/* Panel Header */}
            <div className="p-4 border-b border-border flex items-center justify-between">
              <h2 className="font-semibold">{selectedProject ? "Project Details" : "Select a Project"}</h2>
              <Button size="icon" variant="ghost" onClick={() => setRightPanelOpen(false)}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>

            <ScrollArea className="flex-1">
              {selectedProject ? (
                <div className="p-4 space-y-4">
                  {/* Project Image */}
                  <div className="relative w-full h-48 rounded-lg overflow-hidden bg-muted">
                    <Image
                      src={selectedProject.image || "/placeholder.svg"}
                      alt={selectedProject.name}
                      fill
                      className="object-cover"
                      unoptimized
                    />
                  </div>

                  {/* Project Info */}
                  <div>
                    <h3 className="text-xl font-bold mb-2">{selectedProject.name}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{selectedProject.location}</p>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Type</span>
                        <Badge variant="secondary">{selectedProject.type}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Status</span>
                        <Badge variant="outline">{selectedProject.status}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Year</span>
                        <span className="text-sm font-medium">{selectedProject.year}</span>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full">View Full Project</Button>
                </div>
              ) : (
                <div className="p-4">
                  <div className="text-center py-12 text-muted-foreground">
                    <MapPin className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p className="text-sm">Click on a marker to view project details</p>
                  </div>
                </div>
              )}
            </ScrollArea>
          </>
        )}

        {!rightPanelOpen && (
          <Button
            size="icon"
            variant="ghost"
            className="absolute top-20 right-4 z-20"
            onClick={() => setRightPanelOpen(true)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  )
}
