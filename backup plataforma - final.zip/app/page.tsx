"use client"

import { useState } from "react"
import { useRouter } from "next/navigation" // Added import for useRouter
import { motion, AnimatePresence } from "framer-motion"
import {
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Bot,
  Sparkles,
  Layout,
  Menu,
  X,
  Info,
  ZoomIn,
  ZoomOut,
  Box,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"
import { Navigation } from "@/components/navigation" // Fixed import to use named export instead of default
import InteractiveMap from "@/components/interactive-map"
import AISearchInterface from "@/components/ai-search-interface"
import Link from "next/link"
import { HeroSection } from "@/components/hero-section" // Import HeroSection

// State machine: 'hero' -> 'explorer'
type AppState = "hero" | "explorer"

export default function HomePage() {
  const router = useRouter() // Initialized useRouter
  const [mobileLeftMenuOpen, setMobileLeftMenuOpen] = useState(false)
  const [mobileRightMenuOpen, setMobileRightMenuOpen] = useState(false)

  const [appState, setAppState] = useState<AppState>("hero")
  const [mapColorMode, setMapColorMode] = useState<"dark" | "teal">("dark")
  const [leftSidebarOpen, setLeftSidebarOpen] = useState(true)
  const [rightSidebarOpen, setRightSidebarOpen] = useState(true)
  const [bottomPanelOpen, setBottomPanelOpen] = useState(false) // Start collapsed by default
  const [selectedProject, setSelectedProject] = useState<any>(null)
  const [aiNavigatorOpen, setAiNavigatorOpen] = useState(true)
  const [projectDetailsOpen, setProjectDetailsOpen] = useState(true)

  const handleInitiate = () => {
    router.push("/explorer")
  }

  return (
    <main className="relative w-full h-screen overflow-hidden bg-black">
      <AnimatePresence mode="wait">
        {appState === "hero" && (
          <motion.div
            key="hero"
            exit={{ opacity: 0, scale: 1.1, filter: "blur(10px)" }}
            transition={{ duration: 0.8 }}
            className="relative z-20 w-full h-full"
          >
            <Navigation isHidden={true} />
            <div className="md:hidden fixed top-4 left-4 z-[100]">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileLeftMenuOpen(true)}
                className="h-10 w-10 rounded-full bg-black/80 border border-white/20 text-white hover:bg-black hover:border-white/40 backdrop-blur-sm shadow-lg"
              >
                <Menu className="w-5 h-5" />
              </Button>
            </div>
            <div className="md:hidden fixed top-4 right-4 z-[100]">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileRightMenuOpen(true)}
                className="h-10 w-10 rounded-full bg-black/80 border border-white/20 text-white hover:bg-black hover:border-white/40 backdrop-blur-sm shadow-lg"
              >
                <Layout className="w-5 h-5" />
              </Button>
            </div>
            <HeroSection onInitiate={handleInitiate} />
            {/* Pre-render map content invisibly to ensure smooth transition */}
            <div className="opacity-0 fixed inset-0 pointer-events-none -z-10">
              <InteractiveMap />
            </div>
          </motion.div>
        )}

        {appState === "explorer" && (
          <motion.div
            key="explorer"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="fixed inset-0 z-10 md:flex h-screen w-full"
          >
            <Navigation isHidden={true} />

            <AnimatePresence>
              {mobileLeftMenuOpen && (
                <>
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-[110]"
                    onClick={() => setMobileLeftMenuOpen(false)}
                  />
                  <motion.div
                    initial={{ x: "-100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "-100%" }}
                    transition={{ type: "spring", damping: 25, stiffness: 200 }}
                    className="md:hidden fixed left-0 top-0 bottom-0 w-[85vw] max-w-sm bg-black border-r border-white/10 z-[120] overflow-hidden"
                  >
                    <div className="p-4 h-full flex flex-col">
                      <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-2 text-white/80">
                          <MessageSquare className="w-5 h-5" />
                          <h2 className="font-semibold">Chats</h2>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setMobileLeftMenuOpen(false)}
                          className="h-8 w-8 text-white/50 hover:text-white"
                        >
                          <X className="w-5 h-5" />
                        </Button>
                      </div>
                      <ScrollArea className="flex-1">
                        <div className="space-y-4">
                          <div className="p-3 rounded-lg bg-white/5 border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
                            <h3 className="text-sm font-medium text-white mb-1">Sustainable Housing Chile</h3>
                            <p className="text-xs text-white/50">Last active 2h ago</p>
                          </div>
                          <div className="p-3 rounded-lg bg-white/5 border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
                            <h3 className="text-sm font-medium text-white mb-1">Solar Integration Research</h3>
                            <p className="text-xs text-white/50">Last active 1d ago</p>
                          </div>
                        </div>
                      </ScrollArea>

                      <div className="mt-auto pt-4 border-t border-white/10">
                        <div className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-white/5 transition-colors cursor-pointer group">
                          <div
                            className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                            style={{ background: "linear-gradient(to top right, #008080, #10b981)" }}
                          >
                            JP
                          </div>
                          <div className="flex flex-col overflow-hidden">
                            <span
                              className="text-sm font-medium text-white transition-colors truncate"
                              style={{ color: "white" }}
                            >
                              Juan Pablo Meniconi
                            </span>
                            <span className="text-[10px] text-white/50 tracking-wider">Free</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>

            {/* Desktop Left Sidebar */}
            <motion.div
              initial={false}
              animate={{ width: leftSidebarOpen ? 320 : 0 }}
              className="hidden md:flex flex-col bg-black/95 border-r border-white/10 backdrop-blur-xl overflow-hidden z-30"
            >
              <div className="p-4 h-full flex flex-col w-[300px]">
                {" "}
                {/* Width 300px for content */}
                <div className="flex items-center gap-2 mb-6 text-white/80">
                  <MessageSquare className="w-5 h-5" />
                  <h2 className="font-semibold">Chats</h2>
                </div>
                <ScrollArea className="flex-1">
                  <div className="space-y-4">
                    <div className="p-3 rounded-lg bg-white/5 border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
                      <h3 className="text-sm font-medium text-white mb-1">Sustainable Housing Chile</h3>
                      <p className="text-xs text-white/50">Last active 2h ago</p>
                    </div>
                    <div className="p-3 rounded-lg bg-white/5 border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
                      <h3 className="text-sm font-medium text-white mb-1">Solar Integration Research</h3>
                      <p className="text-xs text-white/50">Last active 1d ago</p>
                    </div>
                  </div>
                </ScrollArea>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.5 }}
                  className="mt-auto pt-4 border-t border-white/10"
                >
                  <div className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-white/5 transition-colors cursor-pointer group">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                      style={{ background: "linear-gradient(to top right, #008080, #10b981)" }}
                    >
                      JP
                    </div>
                    <div className="flex flex-col overflow-hidden">
                      <span className="text-sm font-medium text-white group-hover:text-white transition-colors truncate">
                        Juan Pablo Meniconi
                      </span>
                      <span className="text-[10px] text-white/50 tracking-wider">Free</span>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>

            <div
              className="hidden md:block absolute left-0 top-1/2 -translate-y-1/2 z-50"
              style={{ left: leftSidebarOpen ? 320 : 0 }} // Match sidebar width
            >
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLeftSidebarOpen(!leftSidebarOpen)}
                className="h-24 w-6 rounded-r-xl bg-black/50 border-y border-r border-white/10 text-white/50 hover:text-white hover:bg-black/80"
              >
                {leftSidebarOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </Button>
            </div>

            {/* Main Content Area - Map + Search */}
            <div className="fixed inset-0 md:relative md:flex-1 md:flex md:flex-col overflow-hidden">
              {/* Map Container */}
              <div className="relative h-screen md:h-full w-full md:flex-1 bg-black overflow-hidden">
                {/* Mobile Menu Buttons - Float over map */}
                <div className="md:hidden absolute top-4 left-0 right-0 z-20 flex items-center justify-between px-4">
                  <Button
                    variant="secondary"
                    size="icon"
                    onClick={() => setMobileLeftMenuOpen(true)}
                    className="h-10 w-10 rounded-full bg-black/80 border border-white/10 text-white hover:bg-black/90 shadow-lg backdrop-blur-sm"
                  >
                    <Menu className="w-5 h-5" />
                  </Button>

                  {selectedProject && (
                    <Button
                      variant="secondary"
                      size="icon"
                      onClick={() => setMobileRightMenuOpen(true)}
                      className="h-10 w-10 rounded-full bg-black/80 border border-white/10 text-white hover:bg-black/90 shadow-lg backdrop-blur-sm"
                    >
                      <Info className="w-5 h-5" />
                    </Button>
                  )}
                </div>

                {/* Zoom Level Indicator */}
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-20 text-white/50 font-mono text-xs md:text-sm bg-black/60 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                  Zoom Level: 1/3 • 100 Projects
                </div>

                {/* Map Controls (Right Side) */}
                <div className="absolute right-4 top-20 md:top-24 z-20 flex flex-col gap-3">
                  <Button
                    variant="secondary"
                    size="icon"
                    className="h-10 w-10 rounded-full bg-black/80 border border-white/10 text-white hover:bg-black/90 shadow-lg backdrop-blur-sm"
                  >
                    <ZoomIn className="w-5 h-5" />
                  </Button>
                  <Button
                    variant="secondary"
                    size="icon"
                    className="h-10 w-10 rounded-full bg-black/80 border border-white/10 text-white hover:bg-black/90 shadow-lg backdrop-blur-sm"
                  >
                    <ZoomOut className="w-5 h-5" />
                  </Button>
                  <Button
                    variant="secondary"
                    size="icon"
                    className="h-10 w-10 rounded-full bg-black/80 border border-white/10 text-white hover:bg-black/90 shadow-lg backdrop-blur-sm"
                  >
                    <Box className="w-5 h-5" />
                  </Button>
                </div>

                {/* Interactive Map */}
                <div className="absolute inset-0 z-[1]">
                  <InteractiveMap
                    colorMode={mapColorMode}
                    onProjectSelect={(project) => {
                      setSelectedProject(project)
                      if (window.innerWidth < 768) {
                        setMobileRightMenuOpen(true)
                      } else {
                        setRightSidebarOpen(true)
                      }
                    }}
                  />
                  {/* Gradient overlays for depth */}
                  <div className="absolute bottom-0 left-0 right-0 h-24 md:h-32 bg-gradient-to-t from-black via-black/60 to-transparent pointer-events-none z-[5]" />
                  <div className="hidden md:block absolute top-0 bottom-0 left-0 w-32 bg-gradient-to-r from-black via-black/50 to-transparent pointer-events-none z-[5]" />
                  <div className="hidden md:block absolute top-0 bottom-0 right-0 w-32 bg-gradient-to-l from-black via-black/50 to-transparent pointer-events-none z-[5]" />
                </div>

                {/* Search Overlay - Floats over map */}
                <div className="absolute bottom-0 left-0 right-0 md:inset-0 z-10 flex flex-col justify-end pb-4 md:pb-6 px-4 md:px-0 pointer-events-none">
                  <div className="pointer-events-auto w-full">
                    <AISearchInterface onSearch={() => setMapColorMode("teal")} />
                  </div>
                </div>
              </div>

              {/* Bottom Panel: Project Types - Desktop only */}
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: bottomPanelOpen ? "auto" : "40px" }}
                className="hidden md:flex bg-black/90 border-t border-white/10 backdrop-blur-xl z-20 flex-shrink-0 flex-col relative"
              >
                {/* Collapse/Expand Button */}
                <div className="w-full flex justify-center -mt-3 absolute top-0 z-30 pointer-events-none">
                  <Button
                    variant="secondary"
                    size="sm"
                    className="h-6 w-24 rounded-full border border-white/10 bg-black/80 text-white/50 hover:text-white text-[10px] pointer-events-auto shadow-lg"
                    onClick={() => setBottomPanelOpen(!bottomPanelOpen)}
                  >
                    {bottomPanelOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />}
                  </Button>
                </div>

                <div className="p-4 overflow-hidden">
                  {/* Header only visible when open to avoid clutter when closed */}
                  <div className={`flex items-center justify-between mb-4 ${!bottomPanelOpen && "opacity-0"}`}>
                    <div className="flex items-center gap-4">
                      <h3 className="text-sm font-medium text-white/80">Project Types</h3>
                      <div className="relative hidden md:block">
                        <input
                          type="text"
                          placeholder="Search filters..."
                          className="bg-white/5 border border-white/10 rounded-full px-3 py-1 text-xs text-white placeholder:text-white/30 focus:outline-none w-32 transition-all focus:w-48"
                          style={{ outlineColor: "#008080" }}
                          onFocus={(e) => (e.target.style.borderColor = "#00808080")}
                          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.1)")}
                        />
                      </div>
                    </div>
                    <span className="hidden md:inline text-xs text-white/40 pr-6">Filter by category</span>
                  </div>

                  <div className="flex flex-wrap gap-2 justify-center pb-2">
                    {[
                      "Bamboo",
                      "Car-Free",
                      "Carbon Neutral",
                      "Energy Positive",
                      "Green Building",
                      "LEED Platinum",
                      "Living Building",
                      "Net Positive",
                      "Net Zero",
                      "Passive House",
                      "Retrofit",
                      "Smart City",
                      "Solar",
                      "Solar District",
                      "Vertical Garden",
                      "Wind Power",
                      "Zero Carbon",
                    ].map((type) => (
                      <button
                        key={type}
                        className="px-3 py-1.5 text-xs font-medium text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-all border border-white/10 hover:border-white/30 bg-white/5"
                      >
                        {type}
                      </button>
                    ))}
                    <button
                      className="px-3 py-1.5 text-xs font-bold rounded-full transition-all border bg-opacity-10"
                      style={{ color: "#008080", borderColor: "#00808080", backgroundColor: "#00808020" }}
                    >
                      +100
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>

            <AnimatePresence>
              {mobileRightMenuOpen && (
                <>
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-[110]"
                    onClick={() => setMobileRightMenuOpen(false)}
                  />
                  <motion.div
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    transition={{ type: "spring", damping: 25, stiffness: 200 }}
                    className="md:hidden fixed right-0 top-0 bottom-0 w-[85vw] max-w-sm bg-black border-l border-white/10 z-[120] overflow-hidden"
                  >
                    <div className="p-4 h-full flex flex-col">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2 text-white/80">
                          <Layout className="w-4 h-4" />
                          <h2 className="font-semibold">Project Details</h2>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setMobileRightMenuOpen(false)}
                          className="h-8 w-8 text-white/50 hover:text-white"
                        >
                          <X className="w-5 h-5" />
                        </Button>
                      </div>

                      <ScrollArea className="flex-1">
                        {selectedProject ? (
                          <div className="space-y-4">
                            <Button asChild className="w-full text-white" style={{ backgroundColor: "#008080" }}>
                              <Link href={`/project/${selectedProject.name.toLowerCase().replace(/\s+/g, "-")}`}>
                                View Full Project →
                              </Link>
                            </Button>

                            <div className="relative w-full h-40 rounded-lg overflow-hidden">
                              <img
                                src={selectedProject.image || "/placeholder.svg?height=160&width=300"}
                                alt={selectedProject.name}
                                className="w-full h-full object-cover"
                              />
                            </div>

                            <div>
                              <h3 className="text-lg font-bold text-white mb-1">{selectedProject.name}</h3>
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-white/50">Location</span>
                                <span className="text-white">{selectedProject.location}</span>
                              </div>
                            </div>

                            <div className="flex items-center justify-between text-sm">
                              <span className="text-white/50">Type</span>
                              <span style={{ color: "#008080" }}>{selectedProject.type}</span>
                            </div>

                            <div className="space-y-3">
                              <h4 className="text-sm font-medium text-white/80">Climate</h4>
                              <div className="grid grid-cols-2 gap-2">
                                <div className="p-2 rounded-lg bg-white/5 border border-white/10">
                                  <div className="text-[10px] text-white/50 mb-1">Avg Temp</div>
                                  <div className="text-sm font-semibold" style={{ color: "#008080" }}>
                                    18°C
                                  </div>
                                </div>
                                <div className="p-2 rounded-lg bg-white/5 border border-white/10">
                                  <div className="text-[10px] text-white/50 mb-1">Zone</div>
                                  <div className="text-sm font-semibold" style={{ color: "#008080" }}>
                                    BWk
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="space-y-3">
                              <h4 className="text-sm font-medium text-white/80">Energy Demand (kWh/m²·yr)</h4>
                              <div className="space-y-2">
                                <div>
                                  <div className="flex justify-between text-xs mb-1">
                                    <span className="text-white/60">Solar Gain</span>
                                    <span className="text-yellow-400 font-semibold">50.5</span>
                                  </div>
                                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                    <div
                                      className="h-full bg-gradient-to-r from-yellow-500 to-amber-400 rounded-full"
                                      style={
                                        {
                                          width: "50.5%",
                                          animation: "progressGrow 0.7s ease-out forwards",
                                          animationDelay: "0.05s",
                                          "--final-width": "50.5%",
                                        } as any
                                      }
                                    />
                                  </div>
                                </div>
                                <div>
                                  <div className="flex justify-between text-xs mb-1">
                                    <span className="text-white/60">Heating</span>
                                    <span className="text-orange-400 font-semibold">27.5</span>
                                  </div>
                                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                    <div
                                      className="h-full bg-gradient-to-r from-orange-500 to-red-400 rounded-full"
                                      style={
                                        {
                                          width: "27.5%",
                                          animation: "progressGrow 0.7s ease-out forwards",
                                          animationDelay: "0.15s",
                                          "--final-width": "27.5%",
                                        } as any
                                      }
                                    />
                                  </div>
                                </div>
                                <div>
                                  <div className="flex justify-between text-xs mb-1">
                                    <span className="text-white/60">Cooling</span>
                                    <span className="text-blue-400 font-semibold">5.6</span>
                                  </div>
                                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                    <div
                                      className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full"
                                      style={
                                        {
                                          width: "5.6%",
                                          animation: "progressGrow 0.7s ease-out forwards",
                                          animationDelay: "0.25s",
                                          "--final-width": "5.6%",
                                        } as any
                                      }
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="space-y-3">
                              <h4 className="text-sm font-medium text-white/80">Building Envelope</h4>
                              <div className="space-y-2 text-xs">
                                <div className="flex justify-between">
                                  <span className="text-white/60">Glazing</span>
                                  <span className="text-white">Low-E Triple (1.8 W/m²K)</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-white/60">Window-Wall Ratio</span>
                                  <span className="text-white">10.17%</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-white/60">Solar Orientation</span>
                                  <span className="text-white">North (optimized)</span>
                                </div>
                              </div>
                            </div>

                            <div className="space-y-3">
                              <h4 className="text-sm font-medium text-white/80">Materials</h4>
                              <div className="space-y-2">
                                <div>
                                  <div className="flex justify-between text-xs mb-1">
                                    <span className="text-white/60">Adobe (Walls)</span>
                                    <span className="font-semibold" style={{ color: "#008080" }}>
                                      415 m³
                                    </span>
                                  </div>
                                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                    <div
                                      className="h-full rounded-full"
                                      style={{ width: "65%", backgroundColor: "#008080" }}
                                    />
                                  </div>
                                </div>
                                <div>
                                  <div className="flex justify-between text-xs mb-1">
                                    <span className="text-white/60">Mineral Wool</span>
                                    <span className="font-semibold" style={{ color: "#008080" }}>
                                      120 m²
                                    </span>
                                  </div>
                                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                    <div
                                      className="h-full rounded-full"
                                      style={{ width: "35%", backgroundColor: "#008080" }}
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="space-y-3">
                              <h4 className="text-sm font-medium text-white/80">Sustainability Metrics</h4>
                              <div className="grid grid-cols-2 gap-2">
                                <div
                                  className="p-3 rounded-lg border"
                                  style={{ backgroundColor: "#00808020", borderColor: "#00808080" }}
                                >
                                  <div className="text-[10px] mb-1" style={{ color: "#008080b3" }}>
                                    Carbon Saved
                                  </div>
                                  <div className="text-base font-bold" style={{ color: "#008080" }}>
                                    -70.8 tCO₂e
                                  </div>
                                </div>
                                <div
                                  className="p-3 rounded-lg border"
                                  style={{ backgroundColor: "#00808020", borderColor: "#00808080" }}
                                >
                                  <div className="text-[10px] mb-1" style={{ color: "#008080b3" }}>
                                    Solar Gen.
                                  </div>
                                  <div className="text-base font-bold" style={{ color: "#008080" }}>
                                    4 kWp
                                  </div>
                                </div>
                              </div>
                            </div>

                            <p className="text-xs text-white/60 leading-relaxed">
                              This project demonstrates cutting-edge sustainable architecture principles, utilizing
                              passive cooling, thermal mass, and renewable energy integration.
                            </p>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center justify-center h-full text-center">
                            <Layout className="w-12 h-12 text-white/20 mb-3" />
                            <p className="text-sm text-white/40">Select a project on the map to view details</p>
                          </div>
                        )}
                      </ScrollArea>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>

            <div
              className="hidden md:block absolute top-1/2 -translate-y-1/2 z-50 transition-all duration-300 pointer-events-auto"
              style={{ right: rightSidebarOpen ? 300 : 0 }}
            >
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setRightSidebarOpen(!rightSidebarOpen)}
                className={cn(
                  "h-24 w-8 rounded-l-xl border-y border-l border-white/10 text-white/50 hover:text-white backdrop-blur-sm transition-colors absolute right-0",
                  rightSidebarOpen
                    ? "bg-black/50 hover:bg-black/80 translate-x-0"
                    : "bg-black/80 hover:bg-black border-white/20 text-white shadow-[-4px_0_10px_rgba(0,0,0,0.5)] -translate-x-[1px]", // Adjusted translation to ensure tight fit
                )}
              >
                {rightSidebarOpen ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5 ml-1" />}
              </Button>
            </div>

            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: rightSidebarOpen ? 300 : 0, opacity: rightSidebarOpen ? 1 : 0 }}
              className="hidden md:block h-full bg-black/90 border-l border-white/10 backdrop-blur-xl overflow-hidden relative z-50 flex-shrink-0"
            >
              <div className="p-4 h-full flex flex-col w-[300px]">
                <div className="mb-4">
                  <button
                    onClick={() => setAiNavigatorOpen(!aiNavigatorOpen)}
                    className="flex items-center justify-between w-full text-white/80 hover:text-white transition-colors group"
                  >
                    <div className="flex items-center gap-2">
                      <Bot className="w-5 h-5" />
                      <h2 className="font-semibold">AI Agent & Navigator</h2>
                    </div>
                    {aiNavigatorOpen ? (
                      <ChevronUp className="w-4 h-4 text-white/50 group-hover:text-white transition-colors" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-white/50 group-hover:text-white transition-colors" />
                    )}
                  </button>

                  <AnimatePresence>
                    {aiNavigatorOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className="space-y-4 mt-4">
                          <div
                            className="p-4 rounded-lg border"
                            style={{ backgroundColor: "#00808020", borderColor: "#00808080" }}
                          >
                            <div className="flex items-center gap-2 mb-2" style={{ color: "#008080" }}>
                              <Sparkles className="w-4 h-4" />
                              <span className="text-sm font-medium">Auto-Navigator</span>
                            </div>
                            <p className="text-xs text-white/60 mb-3">Delegate research tasks to your AI agent.</p>
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-full bg-transparent"
                              style={{ borderColor: "#00808080", color: "#008080" }}
                            >
                              Start New Task
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Project Details */}
                <div className="flex-1 flex flex-col overflow-hidden">
                  <button
                    onClick={() => setProjectDetailsOpen(!projectDetailsOpen)}
                    className="flex items-center justify-between w-full text-white/80 hover:text-white transition-colors group mb-4"
                  >
                    <div className="flex items-center gap-2">
                      <Layout className="w-4 h-4" />
                      <h2 className="font-semibold">Project Details</h2>
                    </div>
                    {projectDetailsOpen ? (
                      <ChevronUp className="w-4 h-4 text-white/50 group-hover:text-white transition-colors" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-white/50 group-hover:text-white transition-colors" />
                    )}
                  </button>

                  <AnimatePresence>
                    {projectDetailsOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden flex-1 flex flex-col"
                      >
                        {selectedProject ? (
                          <ScrollArea className="flex-1">
                            <div
                              key={selectedProject.name}
                              className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300"
                            >
                              <Button asChild className="w-full text-white" style={{ backgroundColor: "#008080" }}>
                                <Link href={`/project/${selectedProject.name.toLowerCase().replace(/\s+/g, "-")}`}>
                                  View Full Project →
                                </Link>
                              </Button>

                              <div className="relative w-full h-40 rounded-lg overflow-hidden">
                                <img
                                  src={selectedProject.image || "/placeholder.svg?height=160&width=300"}
                                  alt={selectedProject.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>

                              <div>
                                <h3 className="text-lg font-bold text-white mb-1">{selectedProject.name}</h3>
                                <div className="flex items-center justify-between text-sm">
                                  <span className="text-white/50">Location</span>
                                  <span className="text-white">{selectedProject.location}</span>
                                </div>
                              </div>

                              <div className="flex items-center justify-between text-sm">
                                <span className="text-white/50">Type</span>
                                <span style={{ color: "#008080" }}>{selectedProject.type}</span>
                              </div>

                              <div className="space-y-3">
                                <h4 className="text-sm font-medium text-white/80">Climate</h4>
                                <div className="grid grid-cols-2 gap-2">
                                  <div className="p-2 rounded-lg bg-white/5 border border-white/10">
                                    <div className="text-[10px] text-white/50 mb-1">Avg Temp</div>
                                    <div className="text-sm font-semibold" style={{ color: "#008080" }}>
                                      18°C
                                    </div>
                                  </div>
                                  <div className="p-2 rounded-lg bg-white/5 border border-white/10">
                                    <div className="text-[10px] text-white/50 mb-1">Zone</div>
                                    <div className="text-sm font-semibold" style={{ color: "#008080" }}>
                                      BWk
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div className="space-y-3">
                                <h4 className="text-sm font-medium text-white/80">Energy Demand (kWh/m²·yr)</h4>
                                <div className="space-y-2">
                                  <div>
                                    <div className="flex justify-between text-xs mb-1">
                                      <span className="text-white/60">Solar Gain</span>
                                      <span className="text-yellow-400 font-semibold">50.5</span>
                                    </div>
                                    <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                      <div
                                        className="h-full bg-gradient-to-r from-yellow-500 to-amber-400 rounded-full"
                                        style={
                                          {
                                            width: "50.5%",
                                            animation: "progressGrow 0.7s ease-out forwards",
                                            animationDelay: "0.05s",
                                            "--final-width": "50.5%",
                                          } as any
                                        }
                                      />
                                    </div>
                                  </div>
                                  <div>
                                    <div className="flex justify-between text-xs mb-1">
                                      <span className="text-white/60">Heating</span>
                                      <span className="text-orange-400 font-semibold">27.5</span>
                                    </div>
                                    <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                      <div
                                        className="h-full bg-gradient-to-r from-orange-500 to-red-400 rounded-full"
                                        style={
                                          {
                                            width: "27.5%",
                                            animation: "progressGrow 0.7s ease-out forwards",
                                            animationDelay: "0.15s",
                                            "--final-width": "27.5%",
                                          } as any
                                        }
                                      />
                                    </div>
                                  </div>
                                  <div>
                                    <div className="flex justify-between text-xs mb-1">
                                      <span className="text-white/60">Cooling</span>
                                      <span className="text-blue-400 font-semibold">5.6</span>
                                    </div>
                                    <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                      <div
                                        className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full"
                                        style={
                                          {
                                            width: "5.6%",
                                            animation: "progressGrow 0.7s ease-out forwards",
                                            animationDelay: "0.25s",
                                            "--final-width": "5.6%",
                                          } as any
                                        }
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div className="space-y-3">
                                <h4 className="text-sm font-medium text-white/80">Building Envelope</h4>
                                <div className="space-y-2 text-xs">
                                  <div className="flex justify-between">
                                    <span className="text-white/60">Glazing</span>
                                    <span className="text-white">Low-E Triple (1.8 W/m²K)</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-white/60">Window-Wall Ratio</span>
                                    <span className="text-white">10.17%</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-white/60">Solar Orientation</span>
                                    <span className="text-white">North (optimized)</span>
                                  </div>
                                </div>
                              </div>

                              <div className="space-y-3">
                                <h4 className="text-sm font-medium text-white/80">Materials</h4>
                                <div className="space-y-2">
                                  <div>
                                    <div className="flex justify-between text-xs mb-1">
                                      <span className="text-white/60">Adobe (Walls)</span>
                                      <span className="font-semibold" style={{ color: "#008080" }}>
                                        415 m³
                                      </span>
                                    </div>
                                    <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                      <div
                                        className="h-full rounded-full"
                                        style={{ width: "65%", backgroundColor: "#008080" }}
                                      />
                                    </div>
                                  </div>
                                  <div>
                                    <div className="flex justify-between text-xs mb-1">
                                      <span className="text-white/60">Mineral Wool</span>
                                      <span className="font-semibold" style={{ color: "#008080" }}>
                                        120 m²
                                      </span>
                                    </div>
                                    <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                      <div
                                        className="h-full rounded-full"
                                        style={{ width: "35%", backgroundColor: "#008080" }}
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div className="space-y-3">
                                <h4 className="text-sm font-medium text-white/80">Sustainability Metrics</h4>
                                <div className="grid grid-cols-2 gap-2">
                                  <div
                                    className="p-3 rounded-lg border"
                                    style={{ backgroundColor: "#00808020", borderColor: "#00808080" }}
                                  >
                                    <div className="text-[10px] mb-1" style={{ color: "#008080b3" }}>
                                      Carbon Saved
                                    </div>
                                    <div className="text-base font-bold" style={{ color: "#008080" }}>
                                      -70.8 tCO₂e
                                    </div>
                                  </div>
                                  <div
                                    className="p-3 rounded-lg border"
                                    style={{ backgroundColor: "#00808020", borderColor: "#00808080" }}
                                  >
                                    <div className="text-[10px] mb-1" style={{ color: "#008080b3" }}>
                                      Solar Gen.
                                    </div>
                                    <div className="text-base font-bold" style={{ color: "#008080" }}>
                                      4 kWp
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <p className="text-xs text-white/60 leading-relaxed">
                                This project demonstrates cutting-edge sustainable architecture principles, utilizing
                                passive cooling, thermal mass, and renewable energy integration.
                              </p>
                            </div>
                          </ScrollArea>
                        ) : (
                          <div className="flex flex-col items-center justify-center flex-1 text-center">
                            <Layout className="w-12 h-12 text-white/20 mb-3" />
                            <p className="text-sm text-white/40">Select a project on the map to view details</p>
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Only show static content in Hero mode */}
      {appState === "hero" && <>{/* ... existing static sections ... */}</>}
    </main>
  )
}
