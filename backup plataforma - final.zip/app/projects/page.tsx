import { ProjectsGrid } from "@/components/projects-grid"
import { ProjectFilters } from "@/components/project-filters"

export default function ProjectsPage() {
  return (
    <main className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="mb-12">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 text-balance">Sustainable Architecture Projects</h1>
          <p className="text-lg text-muted-foreground max-w-3xl text-pretty">
            Explore innovative sustainable buildings from around the world. Filter by region, building type, materials,
            and climate zone.
          </p>
        </div>

        <ProjectFilters />
        <ProjectsGrid />
      </div>
    </main>
  )
}
