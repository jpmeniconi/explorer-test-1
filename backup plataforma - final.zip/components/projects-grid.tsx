"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { MapPin, Calendar, Leaf, ExternalLink } from "lucide-react"

interface Project {
  id: number
  title: string
  architect: string
  location: string
  year: number
  type: string
  materials: string[]
  climate: string
  co2Saved: string
  image: string
  description: string
  certifications: string[]
}

const mockProjects: Project[] = [
  {
    id: 1,
    title: "Earthship Biotecture Community",
    architect: "Michael Reynolds",
    location: "Taos, New Mexico, USA",
    year: 2019,
    type: "Residential",
    materials: ["Recycled", "Earth"],
    climate: "Arid",
    co2Saved: "85%",
    image: "/sustainable-earthship-building-desert.jpg",
    description:
      "A fully off-grid community using recycled materials and passive solar design. Features rainwater harvesting, solar power, and natural temperature regulation.",
    certifications: ["Living Building Challenge", "Net Zero Energy"],
  },
  {
    id: 2,
    title: "Bosco Verticale",
    architect: "Stefano Boeri",
    location: "Milan, Italy",
    year: 2014,
    type: "Residential",
    materials: ["Concrete", "Steel"],
    climate: "Temperate",
    co2Saved: "92%",
    image: "/vertical-forest-building-green-facade.jpg",
    description:
      "Twin residential towers featuring over 900 trees and 20,000 plants. Absorbs CO2, produces oxygen, and provides natural insulation.",
    certifications: ["LEED Gold", "International Highrise Award"],
  },
  {
    id: 3,
    title: "The Edge",
    architect: "PLP Architecture",
    location: "Amsterdam, Netherlands",
    year: 2015,
    type: "Commercial",
    materials: ["Steel", "Recycled"],
    climate: "Temperate",
    co2Saved: "98%",
    image: "/modern-sustainable-office-building-glass.jpg",
    description:
      "One of the world's most sustainable office buildings. Features smart LED lighting, solar panels, and an aquifer thermal energy storage system.",
    certifications: ["BREEAM Outstanding", "Net Positive Energy"],
  },
  {
    id: 4,
    title: "Green School Bali",
    architect: "PT Bambu",
    location: "Bali, Indonesia",
    year: 2008,
    type: "Institutional",
    materials: ["Bamboo", "Earth"],
    climate: "Tropical",
    co2Saved: "78%",
    image: "/bamboo-school-building-tropical-architecture.jpg",
    description:
      "An innovative school built entirely from bamboo. Features natural ventilation, solar power, and a micro-hydro vortex for electricity generation.",
    certifications: ["Green Building Council", "UNESCO Recognition"],
  },
  {
    id: 5,
    title: "Bullitt Center",
    architect: "Miller Hull Partnership",
    location: "Seattle, Washington, USA",
    year: 2013,
    type: "Commercial",
    materials: ["Timber", "Recycled"],
    climate: "Temperate",
    co2Saved: "95%",
    image: "/sustainable-office-building-solar-panels.jpg",
    description:
      "A six-story commercial building designed to last 250 years. Features composting toilets, rainwater-to-potable water system, and net-positive energy.",
    certifications: ["Living Building Challenge", "Net Zero Energy"],
  },
  {
    id: 6,
    title: "One Central Park",
    architect: "Jean Nouvel",
    location: "Sydney, Australia",
    year: 2014,
    type: "Mixed-Use",
    materials: ["Concrete", "Steel"],
    climate: "Temperate",
    co2Saved: "88%",
    image: "/vertical-garden-residential-tower.jpg",
    description:
      "Twin residential towers with vertical gardens designed by Patrick Blanc. Features heliostat system reflecting sunlight to shaded areas.",
    certifications: ["5 Star Green Star", "LEED Gold"],
  },
  {
    id: 7,
    title: "Powerhouse Kjørbo",
    architect: "Snøhetta",
    location: "Oslo, Norway",
    year: 2014,
    type: "Commercial",
    materials: ["Timber", "Recycled"],
    climate: "Continental",
    co2Saved: "96%",
    image: "/modern-sustainable-office-norway.jpg",
    description:
      "A retrofit project that transformed 1980s office buildings into energy-positive structures. Produces more energy than it consumes over its lifetime.",
    certifications: ["BREEAM Excellent", "Energy Positive"],
  },
  {
    id: 8,
    title: "Pixel Building",
    architect: "Studio505",
    location: "Melbourne, Australia",
    year: 2010,
    type: "Commercial",
    materials: ["Recycled", "Steel"],
    climate: "Temperate",
    co2Saved: "100%",
    image: "/colorful-sustainable-office-building.jpg",
    description:
      "Australia's first carbon-neutral office building. Features wind turbines, solar panels, and a unique facade with recycled materials.",
    certifications: ["6 Star Green Star", "Carbon Neutral"],
  },
  {
    id: 9,
    title: "Bahrain World Trade Center",
    architect: "Atkins",
    location: "Manama, Bahrain",
    year: 2008,
    type: "Commercial",
    materials: ["Concrete", "Steel"],
    climate: "Arid",
    co2Saved: "82%",
    image: "/twin-towers-wind-turbines-middle-east.jpg",
    description:
      "Twin towers with three integrated wind turbines between them. The first skyscraper to integrate large-scale wind turbines into its design.",
    certifications: ["LEED Silver", "Innovation in Design"],
  },
  {
    id: 10,
    title: "Vauban District",
    architect: "Various",
    location: "Freiburg, Germany",
    year: 2006,
    type: "Mixed-Use",
    materials: ["Timber", "Recycled"],
    climate: "Temperate",
    co2Saved: "90%",
    image: "/sustainable-neighborhood-solar-panels.jpg",
    description:
      "A car-free neighborhood with over 5,000 residents. Features passive house standards, solar power, and extensive green spaces.",
    certifications: ["Passive House", "Solar Settlement"],
  },
  {
    id: 11,
    title: "Manitoba Hydro Place",
    architect: "KPMB Architects",
    location: "Winnipeg, Canada",
    year: 2009,
    type: "Commercial",
    materials: ["Concrete", "Steel"],
    climate: "Continental",
    co2Saved: "94%",
    image: "/modern-sustainable-office-tower-canada.jpg",
    description:
      "A 22-story office tower using 60% less energy than comparable buildings. Features a solar chimney and geothermal heating/cooling.",
    certifications: ["LEED Platinum", "Energy Star"],
  },
  {
    id: 12,
    title: "Taipei 101 Green Retrofit",
    architect: "C.Y. Lee & Partners",
    location: "Taipei, Taiwan",
    year: 2011,
    type: "Commercial",
    materials: ["Steel", "Recycled"],
    climate: "Tropical",
    co2Saved: "86%",
    image: "/taipei-101-skyscraper-sustainable.jpg",
    description:
      "A retrofit of the iconic skyscraper to achieve LEED Platinum. Features energy-efficient systems and waste reduction programs.",
    certifications: ["LEED Platinum", "Green Building"],
  },
  {
    id: 13,
    title: "Phipps Center for Sustainable Landscapes",
    architect: "The Design Alliance",
    location: "Pittsburgh, USA",
    year: 2012,
    type: "Institutional",
    materials: ["Timber", "Recycled"],
    climate: "Temperate",
    co2Saved: "97%",
    image: "/sustainable-landscape-center-green-roof.jpg",
    description:
      "One of the greenest buildings in the world. Features net-zero energy, water, and waste systems with extensive green infrastructure.",
    certifications: ["Living Building Challenge", "LEED Platinum", "SITES Platinum"],
  },
  {
    id: 14,
    title: "Vancouver Convention Centre West",
    architect: "LMN Architects",
    location: "Vancouver, Canada",
    year: 2009,
    type: "Commercial",
    materials: ["Concrete", "Timber"],
    climate: "Temperate",
    co2Saved: "89%",
    image: "/convention-center-green-roof-waterfront.jpg",
    description:
      "Features a 6-acre living roof, seawater heating/cooling, and on-site water treatment. Integrates natural habitat restoration.",
    certifications: ["LEED Platinum", "Green Roof Excellence"],
  },
  {
    id: 15,
    title: "Masdar City",
    architect: "Foster + Partners",
    location: "Abu Dhabi, UAE",
    year: 2016,
    type: "Mixed-Use",
    materials: ["Concrete", "Recycled"],
    climate: "Arid",
    co2Saved: "91%",
    image: "/sustainable-city-middle-east-solar.jpg",
    description:
      "A planned city designed to be carbon-neutral and zero-waste. Features extensive solar power, efficient water use, and sustainable transportation.",
    certifications: ["LEED Neighborhood", "Carbon Neutral Goal"],
  },
]

export function ProjectsGrid() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockProjects.map((project) => (
          <Card
            key={project.id}
            className="group cursor-pointer hover:border-primary/50 transition-all duration-300 overflow-hidden"
            onClick={() => setSelectedProject(project)}
          >
            <div className="relative aspect-[4/3] overflow-hidden bg-muted">
              <img
                src={project.image || "/placeholder.svg"}
                alt={project.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute top-3 right-3">
                <Badge className="text-white" style={{ backgroundColor: "#008080" }}>
                  {project.co2Saved} CO₂ Saved
                </Badge>
              </div>
            </div>
            <CardContent className="p-5">
              <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-1">
                {project.title}
              </h3>
              <p className="text-sm text-muted-foreground mb-3">{project.architect}</p>
              <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                <div className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  <span className="line-clamp-1">{project.location}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  <span>{project.year}</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-1">
                <Badge variant="secondary" className="text-xs">
                  {project.type}
                </Badge>
                {project.materials.slice(0, 2).map((material) => (
                  <Badge key={material} variant="outline" className="text-xs">
                    {material}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Project Detail Modal */}
      <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedProject && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedProject.title}</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div className="relative aspect-video overflow-hidden rounded-lg bg-muted">
                  <img
                    src={selectedProject.image || "/placeholder.svg"}
                    alt={selectedProject.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Architect</div>
                    <div className="font-medium">{selectedProject.architect}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Location</div>
                    <div className="font-medium">{selectedProject.location}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Year</div>
                    <div className="font-medium">{selectedProject.year}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">CO₂ Reduction</div>
                    <div className="font-medium text-primary flex items-center gap-1" style={{ color: "#008080" }}>
                      <Leaf className="h-4 w-4" />
                      {selectedProject.co2Saved}
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Description</h3>
                  <p className="text-muted-foreground leading-relaxed">{selectedProject.description}</p>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Materials</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.materials.map((material) => (
                      <Badge key={material} variant="secondary">
                        {material}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Certifications</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.certifications.map((cert) => (
                      <Badge key={cert} variant="outline" className="border-primary/50">
                        {cert}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button className="flex-1 text-white hover:opacity-90" style={{ backgroundColor: "#008080" }}>
                    <ExternalLink className="mr-2 h-4 w-4" />
                    View Full Case Study
                  </Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    Save to Collection
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
