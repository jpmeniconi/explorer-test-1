"use client"

import type React from "react"
import { usePathname } from "next/navigation"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"

export function LayoutClient({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const showFooter = pathname !== "/map" && pathname !== "/explorer"
  const hideNavigation = false

  return (
    <>
      <Navigation isHidden={hideNavigation} />
      {children}
      {showFooter && <Footer />}
    </>
  )
}
